#include <iostream>

#include <module1/mod1c2.hpp>

void mod1c2::foo()  { std::cout << "mod1c2\n"; }

