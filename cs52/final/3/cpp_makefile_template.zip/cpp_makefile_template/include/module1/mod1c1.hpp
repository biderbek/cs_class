#ifndef MOD1C1_HPP
#define MOD1C1_HPP

#include <iostream>

class mod1c1
{
public:

   void foo(); // { std::cout << "mod1c1\n"; }

};

#endif

