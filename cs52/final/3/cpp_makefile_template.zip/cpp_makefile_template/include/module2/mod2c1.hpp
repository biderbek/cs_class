#ifndef MOD2C1_HPP
#define MOD2C1_HPP

#include <iostream>

class mod2c1
{
public:

   void foo();

};

#endif

